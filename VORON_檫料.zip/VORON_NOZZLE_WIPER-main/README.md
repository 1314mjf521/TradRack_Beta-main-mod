# VORON_NOZZLE_WIPER



WIPER is Must be printed with TPU material

Bucket is need to printed with bridge.


https://www.youtube.com/shorts/77Qln2ZK3aM



![Image of ERCF Toolheadsensor](https://github.com/pure100kim/VORON_NOZZLE_WIPER/blob/main/Pictures/VORON_NOZZLE_WIPER.png)


![Image of ERCF Toolheadsensor](https://github.com/pure100kim/VORON_NOZZLE_WIPER/blob/main/Pictures/VORON_NOZZLE_WIPER1.jpg)


Macro command including pritner.cfg
command is NOZZEL_WIPE

Please set your location directly by yourself.

![Image of ERCF Toolheadsensor](https://github.com/pure100kim/VORON_NOZZLE_WIPER/blob/main/Pictures/VORON_NOZZE_WIPER_MACRO.png)
