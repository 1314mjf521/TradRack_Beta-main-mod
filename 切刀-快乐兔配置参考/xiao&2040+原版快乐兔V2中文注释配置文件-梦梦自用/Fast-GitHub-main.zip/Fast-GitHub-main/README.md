# FAST-GitHub

# 简介

国内 Github 下载很慢，用上了这个插件后，下载速度嗖嗖嗖的~！ 

[![Page Views Count](https://badges.toozhao.com/badges/01EH1R0YMQANV1ACQXTEBK7JCN/green.svg)](https://badges.toozhao.com/badges/01EH1R0YMQANV1ACQXTEBK7JCN/green.svg "Get your own page views count badge on badges.toozhao.com")



# 下载插件

Chrome插件地址更新,很抱歉给大家带来的不便。

<table>
<tbody>
<tr>
<td>
<a href="https://chrome.google.com/webstore/detail/github加速/ffjjnphohkfckeplcjflmgneebafggej" target="_blank">
        <img src="https://i.loli.net/2021/04/23/IqpU7COKQvzrcyG.png" />
      </a>
</td>
<td><a href="https://apps.apple.com/cn/app/fastgithub/id1564025982?mt=12" target="_blank">
        <img src="https://i.loli.net/2021/04/23/SKsywoGWg1HvEja.png" />
      </a></td>
<td>
<a href="https://microsoftedge.microsoft.com/addons/detail/github%E5%8A%A0%E9%80%9F/alhnbdjjbokpmilgemopoomnldpejihb" target="_blank">
        <img src="https://i.loli.net/2021/04/23/EnS3eDi4I86Yv2N.png" />
      </a>
</td>
</tr>
</tbody>
</table>

# 预览

<img width="1383" alt="CleanShot 2022-02-14 at 14 55 25@2x" src="https://user-images.githubusercontent.com/14891797/153814732-d43dbf95-38a3-4145-ac84-a628bc543509.png">

